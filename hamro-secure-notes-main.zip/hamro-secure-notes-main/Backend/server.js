require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const rateLimit = require("express-rate-limit"); // ✅ correct place

const app = express();
app.use(express.json());

const allowedOrigins = [
  "http://localhost:5173",
  process.env.CORS_ORIGIN
].filter(Boolean);

app.use(cors({
  origin: function (origin, callback) {
    if (!origin) return callback(null, true);
    if (allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error("Not allowed by CORS"));
  },
  credentials: true
}));

app.use(helmet());

/* ---------------- RATE LIMIT ---------------- */

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
});

app.use("/api", apiLimiter);

/* -------- REQUIRED ENV VARIABLES -------- */

const requiredEnvs = ["MONGO_URI", "JWT_SECRET"];
const missing = requiredEnvs.filter((k) => !process.env[k]);

if (missing.length) {
  console.error(`❌ Missing environment variables: ${missing.join(", ")}`);
  process.exit(1);
}

/* ------------ DATABASE CONNECTION ------------ */

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ MongoDB Connected'))
  .catch(err => console.error('❌ DB Error:', err));

/* ---------------- SCHEMAS ---------------- */

const UserSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  passwordHash: { type: String, required: true },
  publicKey: { type: String },
  privateKey: { type: String }
});

const NoteSchema = new mongoose.Schema({
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: String,
  ciphertext: { type: String, required: true },
  iv: { type: String, required: true },
  salt: { type: String, required: true },
  signature: { type: String }
}, { timestamps: true });

const User = mongoose.model('User', UserSchema);
const Note = mongoose.model('Note', NoteSchema);

/* ---------------- MIDDLEWARE ---------------- */

const authenticate = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, process.env.JWT_SECRET, { issuer: "hamro-secure-notes" }, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

const requireFields = (fields, body) => {
  const missing = fields.filter((f) =>
    body[f] === undefined || body[f] === null || body[f] === ""
  );
  return missing;
};

/* ---------------- ROUTES ---------------- */

app.post('/api/register', async (req, res) => {
  try {
    const missing = requireFields(["email", "password", "publicKey", "privateKey"], req.body);
    if (missing.length) return res.status(400).json({ error: `Missing: ${missing.join(", ")}` });

    const { email, password, publicKey, privateKey } = req.body;

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    await User.create({ email, passwordHash, publicKey, privateKey });

    res.status(201).json({ message: "User created" });

  } catch (err) {
    console.error("❌ REGISTER ERROR:", err);
    res.status(400).json({ error: "User already exists or Error" });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const missing = requireFields(["email", "password"], req.body);
    if (missing.length) return res.status(400).json({ error: `Missing: ${missing.join(", ")}` });

    const { email, password } = req.body;

    const user = await User.findOne({ email });

    if (!user || !await bcrypt.compare(password, user.passwordHash)) {
      return res.status(400).json({ error: "Invalid credentials" });
    }

    const token = jwt.sign(
      { _id: user._id },
      process.env.JWT_SECRET,
      {
        expiresIn: "2h",
        algorithm: "HS256",
        issuer: "hamro-secure-notes"
      }
    );

    const includeKeys = req.query.includeKeys === "true";

    res.json({
      token,
      publicKey: user.publicKey,
      privateKey: includeKeys ? user.privateKey : undefined
    });

  } catch (e) {
    console.error("LOGIN CRASH:", e);
    res.status(500).json({ error: "Server Error" });
  }
});

/* ---------------- NOTES ---------------- */

app.post('/api/notes', authenticate, async (req, res) => {
  try {
    const missing = requireFields(["ciphertext", "iv", "salt"], req.body);
    if (missing.length) return res.status(400).json({ error: `Missing: ${missing.join(", ")}` });

    const { title, ciphertext, iv, salt, signature } = req.body;

    const note = await Note.create({
      owner: req.user._id,
      title,
      ciphertext,
      iv,
      salt,
      signature
    });

    res.status(201).json(note);

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/notes', authenticate, async (req, res) => {
  const notes = await Note.find({ owner: req.user._id }).sort({ createdAt: -1 });
  res.json(notes);
});

app.patch('/api/notes/:id', authenticate, async (req, res) => {
  try {

    const { title, ciphertext, iv, salt, signature } = req.body;

    const updated = await Note.findOneAndUpdate(
      { _id: req.params.id, owner: req.user._id },
      {
        ...(title !== undefined && { title }),
        ...(ciphertext !== undefined && { ciphertext }),
        ...(iv !== undefined && { iv }),
        ...(salt !== undefined && { salt }),
        ...(signature !== undefined && { signature })
      },
      { new: true }
    );

    if (!updated) return res.status(404).json({ error: "Note not found" });

    res.json(updated);

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/notes/:id', authenticate, async (req, res) => {
  try {
    await Note.findOneAndDelete({ _id: req.params.id, owner: req.user._id });
    res.json({ message: "Note deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* ---------------- HEALTH CHECK ---------------- */

app.get("/health", (req, res) => {
  res.status(200).json({ status: "ok" });
});

/* ---------------- ERROR HANDLER ---------------- */

app.use((err, req, res, next) => {
  console.error("❌ Unhandled Error:", err.message);
  res.status(500).json({ error: "Internal Server Error" });
});

/* ---------------- START SERVER ---------------- */

const PORT = process.env.PORT || 5000;

app.listen(PORT, () =>
  console.log(`🚀 Server running on port ${PORT}`)
);